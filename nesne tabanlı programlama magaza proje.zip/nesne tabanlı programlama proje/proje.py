class Magaza:
    magaza_ad = "STORE"   
    ürün_sayisi = 1000
    siparis_sayisi = 0

    def __init__(self, üst_giyim, alt_giyim, dış_giyim, aksesuar):
        self._üst_giyim = üst_giyim  
        self._alt_giyim = alt_giyim  
        self._dış_giyim = dış_giyim  
        self._aksesuar = aksesuar    

        Magaza.ürün_sayisi += 100
        Magaza.siparis_sayisi += 1

    @property
    def üst_giyim(self):
        return self._üst_giyim
    
    @property
    def alt_giyim(self):
        return self._alt_giyim
    
    @property
    def dış_giyim(self):
        return self._dış_giyim
    
    @property
    def aksesuar(self):
        return self._aksesuar

    @aksesuar.setter
    def aksesuar(self, çanta):
        self._aksesuar = çanta

    def bilgi_getir(self):
        print(f"Üst Giyim: {self.üst_giyim}\nAlt Giyim: {self.alt_giyim}\nDış Giyim: {self.dış_giyim}\nAksesuar: {self.aksesuar}")

    @staticmethod
    def magaza_bilgisi():
        return Magaza.magaza_ad

    @staticmethod
    def siparis_ürün_bilgisi():
        return Magaza.ürün_sayisi

    @classmethod
    def siparis_sayisi_bilgisi(cls):
        return cls.siparis_sayisi

class Kadın(Magaza):
    magaza_ad = "WOMEN STORE"
    siparis_sayisi = 1

    def __init__(self, üst_giyim, alt_giyim, dış_giyim, aksesuar, ayakkabı):
        super().__init__(üst_giyim, alt_giyim, dış_giyim, aksesuar)
        self.ayakkabı = ayakkabı 

    def siparis_sayisi_bilgisi(self):
        return f"Kadın mağazasının sipariş sayısı: {Kadın.siparis_sayisi}"

    def bilgi_getir(self):
        super().bilgi_getir()
        print(f"Ayakkabı: {self.ayakkabı}")

class Erkek(Magaza):
    magaza_ad = "MAN STORE"
    siparis_sayisi = 2

    def __init__(self, üst_giyim, alt_giyim, dış_giyim, aksesuar, ayakkabı):
        super().__init__(üst_giyim, alt_giyim, dış_giyim, aksesuar)
        self.ayakkabı = ayakkabı  

    def siparis_sayisi_bilgisi(self):
        return f"Erkek mağazasının sipariş sayısı: {Erkek.siparis_sayisi}"

    def bilgi_getir(self):
        super().bilgi_getir()
        print(f"Ayakkabı: {self.ayakkabı}")


print("Mağaza Adı:", Magaza.magaza_bilgisi())

sipariş1 = Kadın('Kazak', 'Etek', 'Kaban', 'Atkı', 'Bot')
sipariş1.bilgi_getir()  

print(sipariş1.siparis_sayisi_bilgisi()) 
print("Toplam ürün sayısı:", Magaza.siparis_ürün_bilgisi())

sipariş2 = Erkek('Kazak', 'Pantolon', 'Mont', 'Bere', 'Bot')
sipariş2.bilgi_getir()  

print(sipariş2.siparis_sayisi_bilgisi())  
print("Toplam ürün sayısı:", Magaza.siparis_ürün_bilgisi())








